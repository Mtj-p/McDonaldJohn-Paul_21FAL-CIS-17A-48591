/*
 * file: McDonaldJohnPaul_Project2_Project_CodeBloat_V4
 * Author: John-Paul McDonald
 * Date: 12/18/2021
 * Purpose: Version 4 Starting point: I have no idea how to develop games.
 *          My imagination for writing to specifications is so limited.
 *          I'm going to implement the concepts from chapters 13-16. 
 */




#include <iostream>
#include "Deck.h"
#include "Dealer.h"


using namespace std;



int main(int argc, char** argv) {
    srand(static_cast<unsigned int>(time(0)));
    
   /*  I have no idea how to develop games.
    *  I ran out of time and I can't produce a working game.
    *  I'm going to implement the concepts from chapters 13-16. 
    */
    
    return 0;
}

