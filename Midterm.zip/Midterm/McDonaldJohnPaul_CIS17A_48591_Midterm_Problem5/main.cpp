/*
 * file: 
 * Author: John-Paul McDonald
 * Date: 
 * Purpose: 
 */

//System Libraries
#include <iostream>
#include <iomanip>
using namespace std;

//User Libraries
//Global Constants
//Universal Math, Physics, Conversions, Higher Dimensions
//Prototypes
//Execution Begins Here
int main(int argc, char** argv) {
    cout<<"5a) n=!5 \n"
            "5b) Primitive Data Types:\n"
            "Char"<<setw(40)<<"n=!5\n"
            "Unsigned Char"<<setw(27)<<" n=!5\n"
            "Short Int"<<setw(40)<<"n=!7\n"
            "Unsigned Short Int"<<setw(16)<<" n=!8\n"
            "Int"<<setw(41)<<" n=!12\n"
            "Unsigned Int"<<setw(24)<<" n=!12\n"
            "Long"<<setw(41)<<" n=!20\n"
            "Unsigned Long"<<setw(24)<<" n=!20\n"
            "Float"<<setw(33)<<" n=!19\n"
            "Double"<<setw(37)<<" n=!19\n"
            "Long Double"<<setw(21)<<" n=!19\n";
    return 0;
}
