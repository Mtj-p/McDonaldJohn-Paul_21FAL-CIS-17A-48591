/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Prime.h
 * Author: jaymc
 *
 * Created on October 23, 2021, 8:37 AM
 */

#ifndef PRIME_H
#define PRIME_H


struct Prime{
    unsigned short prime;
    unsigned char power;
};


#endif /* PRIME_H */

