/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Primes.h
 * Author: jaymc
 *
 * Created on October 23, 2021, 8:37 AM
 */

#ifndef PRIMES_H
#define PRIMES_H

struct Primes{
    unsigned char nPrimes;
    Prime *prime;
};

#endif /* PRIMES_H */

