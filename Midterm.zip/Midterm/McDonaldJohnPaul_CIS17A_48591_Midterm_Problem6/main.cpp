/*
 * file: 
 * Author: John-Paul McDonald
 * Date: 
 * Purpose: 
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries
//Global Constants
//Universal Math, Physics, Conversions, Higher Dimensions
//Prototypes
//Execution Begins Here
int main(int argc, char** argv) {
    //Initialize Random Number Seed
    
    //Declare Variables
    cout<<"Hello world";
    //Initialize Variables
    
    //Process the inputs -> outputs
    
    //Display the results, verify inputs
    
    //Clean up and exit
    return 0;
}
